# Paleta de Colores: 
https://colorhunt.co/palette/e5d9b6a4be7b5f8d4e285430
verde oscuro: #285430
verde: #5F8D4E
verde claro: #A4BE7B
crema: #E5D9B6

# Tipografia: 
https://fonts.google.com/specimen/Tajawal?query=taja
https://fonts.google.com/specimen/Josefin+Sans?preview.text=mate%20ar&preview.size=34&preview.text_type=custom&slant=6

