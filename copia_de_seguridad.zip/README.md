#  Mate.ar
Nuestra tienda se dedicará a vender mates, bombillas, termos, contenedor de azucar y yerba, y juegos comlpetos con bolso incluido. Surgio  la idea al pensar en una tienda internacional destinada a argentinos fuera y dentro del pais con envio. 

Estamos dirigidos a adolescentes, adultos e incluso a familias que esperan vivir momentos inolvidables en cualquier lugar listos para compartir un buen mate, lo cual es muy buscado por este público. 

# Nuestro equipo 
está compuesto por  4 miemb:
- Dante Stigliani 
- Genaro Rafault
- Nahir Cabezas 
- Fernando Lepe


# Listado de paginas de referencia o inspiracion:
- Todo mates: diseño muy llamativo y con una idea bastante clara al comunicar al cliente 
https://todomates.com.ar/
- Mercado Libre: la tienda online mas grande de Argentina obviamente nos inspiramos por este
https://www.mercadolibre.com.ar/
- Mateando: pagina consiza y bien organizada
https://www.mateandoarg.com/
- La usina: categoria ofertas implementado interesante asi como la navegacion en el footer  
https://www.bombillasymatesuruguayos.com.ar/
- Wish: otra tienda donde encontras productos bastantes baratos de segunda mano
https://www.wish.com/es

# Trello 
https://trello.com/invite/b/KHmB4qb7/ATTIbafbd1dae60378c75958bf1bc92628ba8453CB68/matear-grupo2
