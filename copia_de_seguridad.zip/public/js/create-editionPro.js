window.addEventListener('load', function(){
    let user = document.querySelectorAll('#user')
    let name = document.querySelectorAll('#name')
    let email = document.querySelectorAll('#email')
    let contra = document.querySelectorAll('#contra')
    let imag = document.querySelectorAll('#imag')

    

})
/* Nombre
■ Obligatorio.
■ Deberá tener al menos 5 caracteres.
○ Descripción
■ Deberá tener al menos 20 caracteres.
○ Imagen
■ Deberá ser un archivo válido (JPG, JPEG, PNG, GIF). */