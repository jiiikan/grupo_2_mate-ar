 # Retrospectiva 
Sprint 1 - Sprint 2 - Sprint 3  

Empezamos un nuevo grupo y con Nahir Cabezas y Fernando Lepe, entonces volvimos hacer los sprints 1, 2, 3 y ahora  empezamos el sprint 4

Ahora teniendo un nuevo grupo, tuvimos que volver organizarnos y lograr ser mas dinamicos con el tiempo  que venimos haciendo.
Tendriamos  que empezar a organizarnos mejor para tener mas eficacia a la hora de hacer los sprints.

sprint 4 
En este nuevo sprint nos desarrollamos de mejor manera en la ejecucion del trabajo en su devido tiempo, tambien pudimos organizarnos mejor en grupo
y logramos pulir nuestro desempeño, ademas logramos llevar a cabo mas reuniones, completamos mas de los sprint anteriores
con una mejora en el diseño de la pagina y en las funcionalidades de esta, pare este proximo sprint intentaremos agregar mas cosas por fuera de las consignas 
establecidas como practicas para dejar una base.

sprint 5
En este sprint tuvimos dificultades a la hora de repartir las tareas, intentamos formar dos grupos separados para la resolucion de los puntos y este llevo a ciertos conflictos internos que logramos resolver asi entregando el trabajo en la fecha de entrega, Empezando con una ventaja de tiempo para la realizacion del siguiente sprint, ademas de ahora comprender el como deberiamos realizar las restrospectivas.

sprint 6
Debido al tiempo extra que tuvimos con este sprint nos relajamos mas de lo que podriamos admitir llegamos al plazo de tiempo muy justos y desorganizados. En la primera reunion se concreto muy bien la organizacion y distribucion de tareas pero con el paso del tiempo no se completo la mayoria de estas. 
En este sprint ya nos dimos cuenta que derrochar el tiempo no conviene y  de la cercania de la finalizacion del proyecto. Como grupo tenemos que lograr una mejor organizacion si queremos completar el proyecto como es debido.

sprint 7

sprint 8
