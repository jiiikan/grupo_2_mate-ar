window.addEventListener('load', function(){
    let user = document.querySelectorAll('#user')
    let name = document.querySelectorAll('#name')
    let email = document.querySelectorAll('#email')
    let contra = document.querySelectorAll('#contra')
    let imag = document.querySelectorAll('#imag')

    

})
/*○ Email
■ Obligatorio.
■ Deberá ser válido.
■ (Opcional) → Debe existir en la base.
○ Contraseña
■ Obligatoria. */